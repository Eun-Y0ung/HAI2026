import base64
import requests

class MediaProcessor:
    def __init__(self, use_gpu=False):
        # No heavy initialization needed for Vision API
        pass

    def encode_image_from_url(self, image_url):
        """Downloads an image from URL and converts it to base64 string."""
        try:
            if not image_url: return None
            
            response = requests.get(image_url, timeout=10)
            response.raise_for_status()
            
            # Convert to base64
            encoded_string = base64.b64encode(response.content).decode('utf-8')
            return encoded_string
            
        except Exception as e:
            print(f"Error encoding image {image_url}: {e}")
            return None

