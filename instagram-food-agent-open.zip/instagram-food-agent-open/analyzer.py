import json
import traceback

class InteractionAnalyzer:
    def __init__(self):
        # 1. Fallback Rule-based Keywords (Updated for Food/Hotplace)
        self.hotplace_keywords = ["웨이팅", "오픈런", "핫플", "가오픈", "팝업스토어", "성수맛집", "연남동카페"]
        self.food_keywords = ["존맛", "JMT", "미친맛", "또간집", "추천", "너무 맛있", "디저트"]
        self.reaction_keywords = ["어디예요", "저장", "가고싶다", "가야지", "대박", "미쳤다"]

        # 3. OpenAI Client
        import config
        from openai import OpenAI
        if config.OPENAI_API_KEY:
            self.client = OpenAI(api_key=config.OPENAI_API_KEY)
        else:
            self.client = None
            print("Warning: OPENAI_API_KEY not found. LLM features disabled.")

    def analyze_and_suggest(self, caption, hashtags, comments, image_base64=None, ui_snapshot=None):
        full_text = f"{caption} {' '.join(hashtags)} {' '.join(comments)}"
        
        # 1. Vision LLM Analysis (GPT-4o) with UI Context
        if self.client:
            print(f"  > [Agentic LLM] Analyzing content + UI context...")
            llm_result = self._analyze_with_llm(full_text, image_base64, ui_snapshot, comments)
            
            if llm_result:
                return {
                    "score": llm_result.get("score", 0),
                    "final_level": llm_result.get("final_level", 0),
                    "interact_like": llm_result.get("interact_like", False),
                    "interact_comment": llm_result.get("interact_comment", False),
                    "evidence": llm_result.get("evidence_quotes", []),
                    "rationale": llm_result.get("rationale", ""),
                    "suggested_reply": llm_result.get("suggested_reply", ""),
                    "uncertain": llm_result.get("uncertain", False),
                    "ocr_text": llm_result.get("image_description", "(Analysis Complete)") 
                }
            else:
                 print("  > [!] LLM Analysis failed. Falling back to Rules.")

        # 2. Fallback: Rule-based Analysis (No Suggested Reply in fallback)
        score, level, evidence, uncertain, reason = self._calculate_rule_score(full_text)
        
        return {
            "score": score,
            "final_level": level,
            "evidence": evidence,
            "uncertain": uncertain,
            "uncertainty_reason": reason,
            "rationale": "Rule-based classification (Fallback)",
            "suggested_reply": "",
            "ocr_text": "(Fallback: No Vision)"
        }

    def _calculate_rule_score(self, text):
        score = 0
        evidence = []
        for kw in self.hotplace_keywords:
            if kw in text: score += 0.2; evidence.append(f"Hotplace: {kw}")
        for kw in self.food_keywords:
            if kw in text: score += 0.3; evidence.append(f"Food: {kw}")
        for kw in self.reaction_keywords:
            if kw in text: score += 0.4; evidence.append(f"Reaction: {kw}")
        
        final_score = min(score, 1.0)
        level = 0 if final_score < 0.3 else (1 if final_score < 0.7 else 2)
        return final_score, level, evidence, False, ""

    def _analyze_with_llm(self, text, image_base64=None, ui_snapshot=None, comments=None):
        try:
            # MCP-Style Prompt: Mimic existing sentiment
            ui_context_str = json.dumps(ui_snapshot, indent=2, ensure_ascii=False) if ui_snapshot else "N/A"
            existing_comments_str = "\n".join([f"- {c}" for c in comments[:10]]) if comments else "None"
            
            prompt = f"""
                You are a Cafe & Restaurant Trend Spotter & Enthusiastic Foodie.
                
                [Input Content]
                Post Caption: {text[:1000]}
                Existing Comments (Reference):
                {existing_comments_str}
                
                UI Structure (Accessibility Tree): {ui_context_str[:1500]}
                
                [Task]
                1. Verify if the content is a Cafe, Restaurant, or Food brand recommendation.
                   - CRITICAL: Read the caption and verify it is a review, visit, or introduction of a real physical restaurant/cafe or commercial food (e.g., mentioning locations, "웨이팅", "맛집", "신메뉴 리뷰").
                   - COMPREHENSIVE REEL JUDGMENT: Food & Cafe accounts predominantly upload Reels (Videos). The provided single screenshot frame might naturally pause on a person's face, a storefront, or an intro title text rather than the food itself. You MUST comprehensively combine the visual context WITH the caption text. If the visual shows a person/influencer but the text explicitly indicates a restaurant/menu review intended for audiences, TRUST THE TEXT and classify it as a valid food review (Level 1/2).
                   - EXCLUDE (Level 0): DO NOT act if the post is about cooking at home, sharing recipes, or home-baking. It MUST be about dining out, buying food, or reviewing commercial food.
                   - EXCLUDE (Level 0): CRITICAL! DO NOT act if the post is just people socializing, celebrities/chefs hanging out, or simple daily life vlogs (일상 공유, 럽스타그램, 친목 도모), EVEN IF they happen to be eating at a restaurant. It MUST be a genuine review, recommendation, or exploration focused primarily on the food or the place itself.
                   - If it aligns with a genuine food/hotplace recommendation, TREAT THE POST as Level 1 or 2.
                2. Analyze the SENTIMENT of the {len(comments)} comments provided.
                3. AGENTIC VISUAL TARGETING: Identify the exact CSS selector or trait of the MAIN POST LIKE BUTTON.
                   - Distinguish it from comment hearts. The main button is usually near the 'Comment' and 'Share' icons under the main image.
                4. DECIDE ACTIONS: LIKE and COMMENT if Level 1 or 2.

                [LEVEL CLASSIFICATION CRITERIA (CRITICAL)]
                - Level 2 (INTERACT): Obvious Restaurant/Cafe/Hotplace reviews, recommendations, or visits. Strong intent to share a "Good Place" with others. (e.g., "여기 진짜 맛집", "성수동 핫플 다녀옴", "웨이팅 보람 있네요", "신상 카페 추천").
                - Level 1 (MONITOR): General food photos, grocery items, or minor mentions of food without a clear "recommendation" or "review" intent. Content that is food-related but not a "Hotplace/Professional Review".
                - Level 0 (SKIP): Home cooking, personal recipes, non-food content, ads, or just friends hanging out without focusing on the place/food.

                [REPLY GUIDELINES]
                - ABSOLUTELY NO EMOJIS.
                - MATCH the style of existing comments (tone, length, politeness).
                - VARY output. Use natural, human-like reactions in Korean.
                - Max 1 short sentence in casual Korean.

                [OUTPUT FORMAT (JSON ONLY)]
                {{
                  "final_level": int (0, 1, 2),
                  "score": float,
                  "interact_like": bool,
                  "interact_comment": bool,
                  "image_description": "Summary in Korean",
                  "evidence_quotes": ["..."],
                  "rationale": "Strategic reasoning. MUST BE IN KOREAN.",
                  "suggested_reply": "[Mimicked Comment in Korean]",
                  "uncertain": bool
                }}
                """
            
            messages = [
                {"role": "system", "content": "You are an agentic analyst. Use both content and UI context to reason."},
                {"role": "user", "content": [{"type": "text", "text": prompt}]}
            ]
            
            if image_base64:
                messages[1]["content"].append({
                    "type": "image_url",
                    "image_url": {"url": f"data:image/jpeg;base64,{image_base64}"}
                })
            
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=messages,
                response_format={"type": "json_object"},
                max_tokens=800
            )
            
            content = response.choices[0].message.content
            if content is None:
                print("  > [!] LLM returned empty content.")
                return None
                
            return json.loads(content)
            
        except Exception as e:
            print(f"  [LLM] Error: {e}")
            return None
