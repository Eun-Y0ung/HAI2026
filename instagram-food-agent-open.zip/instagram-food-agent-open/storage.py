import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os

class InteractionStorageManager:
    def __init__(self, credentials_path, sheet_id):
        self.credentials_path = credentials_path
        self.sheet_id = sheet_id
        self.sheet = None
        self._setup()

    def _setup(self):
        try:
            # 1. Authorize with wider Drive scope for Shared Drive support
            scope = [
                "https://www.googleapis.com/auth/spreadsheets",
                "https://www.googleapis.com/auth/drive"
            ]
            self.creds = ServiceAccountCredentials.from_json_keyfile_name(self.credentials_path, scope)
            self.client = gspread.authorize(self.creds)
            
            # 2. Open by Key (Specific ID) as Shared Drive creation is restricted
            if not self.sheet_id or "YOUR_SPREADSHEET_ID" in self.sheet_id:
                print("  > [!] GOOGLE_SHEET_ID not set correctly in .env. Skipping storage.")
                return

            try:
                # Open the specifically shared sheet via ID
                self.sheet = self.client.open_by_key(self.sheet_id).get_worksheet(0)
                print(f"  > [Storage] Connected to Shared Drive Sheet (ID: {self.sheet_id[:10]}...)")
            except gspread.SpreadsheetNotFound:
                print(f"  > [!] Spreadsheet ID {self.sheet_id} not found or access denied.")
                return

            # 3. Verify Headers
            headers = [
                "Time", "URL", "Content Preview", "Analysis Level", "Score", 
                "Rationale", "Suggested Reply", "Interacted (Like)", "Interacted (Comment)"
            ]
            first_row = self.sheet.row_values(1)
            if not first_row or first_row[0] != "Time":
                print("  > [Storage] Initializing headers in existing sheet.")
                self.sheet.insert_row(headers, 1)
                
        except Exception as e:
            print(f"  > [!] Storage Setup Error: {e}")

    def save_interaction(self, data):
        """Saves interaction results to the sheet."""
        if not self.sheet: return
        try:
            row = [
                data.get("collected_at", ""),
                data.get("url", ""),
                data.get("caption", "")[:100],
                data.get("final_level", 0),
                round(data.get("score", 0), 2),
                data.get("rationale", ""),
                data.get("suggested_reply", ""),
                "YES" if data.get("liked", False) else "NO",
                "YES" if data.get("commented", False) else "NO"
            ]
            self.sheet.append_row(row)
        except Exception as e:
            print(f"Error saving interaction: {e}")

    def get_processed_urls(self):
        """Fetches already processed URLs from the Google Sheet."""
        if not self.sheet: return set()
        try:
            # Assuming URL is in column B (index 2 in gspread 1-based indexing, so col 2)
            urls = self.sheet.col_values(2)
            # Remove header
            if urls and urls[0] == "URL":
                urls = urls[1:]
            print(f"  > [Storage] Loaded {len(urls)} previously processed URLs.")
            return set(urls)
        except Exception as e:
            print(f"  > [!] Error loading processed URLs: {e}")
            return set()
