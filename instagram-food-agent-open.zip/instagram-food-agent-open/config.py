import os
from dotenv import load_dotenv

load_dotenv(override=True)

# Instagram Credentials
INSTAGRAM_USERNAME = os.getenv("INSTAGRAM_USERNAME")
INSTAGRAM_PASSWORD = os.getenv("INSTAGRAM_PASSWORD")

# Google Sheets Credentials
GOOGLE_SHEETS_CREDENTIALS_FILE = os.getenv("GOOGLE_SHEETS_CREDENTIALS_FILE", "credentials.json")
GOOGLE_SHEET_ID = os.getenv("GOOGLE_SHEET_ID")

# OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if OPENAI_API_KEY:
    masked_key = OPENAI_API_KEY[:8] + "..." + OPENAI_API_KEY[-4:]
    print(f"[Config] Loaded OpenAI API Key: {masked_key}")
else:
    print("[Config] No OpenAI API Key found.")
