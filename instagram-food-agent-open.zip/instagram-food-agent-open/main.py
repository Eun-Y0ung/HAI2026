from browser import InstagramInteractionBrowser
from analyzer import InteractionAnalyzer
from storage import InteractionStorageManager
from media_processor import MediaProcessor
import config
import time
import datetime
import random
import os
import json
import base64

def save_debug_report(url, post_data):
    """Saves the screenshot and collected data for user verification."""
    try:
        folder = "debug_data"
        if not os.path.exists(folder):
            os.makedirs(folder)
            
        # Unique mapping: URL -> timestamp_ID
        shortcode = url.strip("/").split("/")[-1] if "/" in url else "unknown"
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename_base = f"{timestamp}_{shortcode}"
        
        # 1. Save Image (The actual view the LLM gets)
        if post_data.get('screenshot_base64'):
            img_path = os.path.join(folder, f"{filename_base}.jpg")
            with open(img_path, "wb") as f:
                f.write(base64.b64decode(post_data['screenshot_base64']))
        
        # 2. Save Metadata (Text context)
        json_path = os.path.join(folder, f"{filename_base}.json")
        debug_info = {
            "url": url,
            "timestamp": timestamp,
            "caption": post_data.get('caption', ''),
            "collected_comments": post_data.get('existing_comments', []),
            "detected_count": len(post_data.get('existing_comments', [])),
            "llm_analysis": {
                "level": post_data.get('final_level'),
                "rationale": post_data.get('rationale'),
                "suggested_reply": post_data.get('suggested_reply')
            }
        }
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(debug_info, f, ensure_ascii=False, indent=2)
            
        print(f"  > [Debug] Saved visual & text log to {folder}/{filename_base}")
    except Exception as e:
        print(f"  > [Debug Error] Failed to save logs: {e}")

# SAFETY SETTINGS
DRY_RUN = False  # Set to False to actually Like/Comment
MAX_INTERACTIONS = 10 # Hard limit per run (Change this to increase interaction count)
INTERACTION_PROBABILITY = 1.0 # 100% chance to interact if target found

def main():
    print("=== Instagram Food & Cafe Interaction Agent ===")
    print(f"MODE: {'[DRY RUN - No actual posting]' if DRY_RUN else '[LIVE - WILL LIKE/COMMENT]'}")
    
    # Initialize components
    browser = InstagramInteractionBrowser(headless=False)
    processor = MediaProcessor()
    analyzer = InteractionAnalyzer() # Political Analysis
    
    # Initialize Google Sheets Storage
    storage = InteractionStorageManager(config.GOOGLE_SHEETS_CREDENTIALS_FILE, config.GOOGLE_SHEET_ID)
    
    # Keep track of processed URLs across sessions
    processed_urls = storage.get_processed_urls()
    interaction_count = 0
    
    try:
        browser.start()
        if config.INSTAGRAM_USERNAME and config.INSTAGRAM_PASSWORD:
            browser.login(config.INSTAGRAM_USERNAME, config.INSTAGRAM_PASSWORD)
        
        while interaction_count < MAX_INTERACTIONS:
            browser.go_to_feed() # Ensure we are on the feed initially
            
            while interaction_count < MAX_INTERACTIONS:
                url = browser.get_next_unprocessed_post_modal(processed_urls)
                
                if not url:
                    print("No more new posts found. Scrolling...")
                    time.sleep(5)
                    continue

                processed_urls.add(url)
                
                try:
                    # A. Analysis Phase (from the OPEN modal)
                    post_data = browser.parse_post_details_from_modal(url)
                    
                    image_base64 = None
                    if post_data.get('screenshot_base64'):
                        image_base64 = post_data['screenshot_base64']
                    elif post_data.get('thumbnail_url'):
                        image_base64 = processor.encode_image_from_url(post_data['thumbnail_url'])
                    
                    result = analyzer.analyze_and_suggest(
                        post_data.get('caption', ''), [], 
                        post_data.get('existing_comments', []),
                        image_base64=image_base64,
                        ui_snapshot=post_data.get('ui_snapshot')
                    )
                    
                    if not result:
                        browser.close_post_modal()
                        continue
                        
                    post_data.update(result)
                    post_data["collected_at"] = datetime.datetime.now().isoformat()
                    
                    # --- DEBUG LOGGING: Save what was collected ---
                    save_debug_report(url, post_data)
                    # ---------------------------------------------
                    
                    # Ensure execution defaults are explicitly False regardless of what the LLM decided
                    post_data["liked"] = False
                    post_data["commented"] = False
                    
                    # B. Interaction Phase
                    if post_data['final_level'] >= 1:
                        print(f"\n[TARGET] {url} (Level {post_data['final_level']})")
                        print(f"Rationale: {post_data['rationale']}")
                        print(f"Suggested Reply: {post_data['suggested_reply']}")
                        
                        # Only Level 2 or higher gets real interaction (Like/Comment)
                        if post_data['final_level'] < 2:
                            print(f"  > [Analysis Only] Skipping interaction for Level 1.")
                            interaction_count += 1
                        elif random.random() < INTERACTION_PROBABILITY:
                            if not DRY_RUN:
                                # We are already in the modal. Verify Modal is still open.
                                modal = browser.page.locator("div[role='dialog']").first
                                if modal.count() == 0 or not modal.is_visible():
                                    print("  > [Safety] Modal closed unexpectedly. Skipping interaction.")
                                    continue
                                    
                                # Simulate Human Reading Delay
                                caption_len = len(post_data.get('caption', ''))
                                reading_time = random.uniform(3.0, 8.0) + (caption_len / 80)
                                reading_time = min(reading_time, 15.0)
                                print(f"  > [Human Behavior] Simulating reading time for {reading_time:.1f} seconds...")
                                time.sleep(reading_time)
                                
                                # 1. Like
                                if result.get('interact_like'):
                                    liked = browser.like_post(analyzer=analyzer)
                                    post_data["liked"] = liked
                                    time.sleep(random.uniform(3.0, 7.0))
                                
                                # 2. Comment
                                existing_comments_list = post_data.get('existing_comments', [])
                                existing_comments_count = len(existing_comments_list)
                                print(f"  > [Check] Actual Comments explicitly detected: {existing_comments_count}")
                                
                                if result.get('interact_comment') and result.get('suggested_reply'):
                                    if existing_comments_count >= 5:
                                        print(f"  > [Interaction] Posting suggested reply...")
                                        commented = browser.post_comment(result['suggested_reply'], analyzer=analyzer)
                                        post_data["commented"] = "YES" if commented else "FAILED"
                                    else:
                                        print(f"  > [Safety] Skipping comment. Only {existing_comments_count} existing comments (Safety Threshold: 5).")
                                        post_data["commented"] = f"SKIPPED (Count: {existing_comments_count})"
                                else:
                                    print(f"  > [Agentic LLM] Decided NOT to comment on this post.")
                                    post_data["commented"] = "NO (LLM Decided)"
                                
                                interaction_count += 1
                                print(f"--- Interaction Done ({interaction_count}/{MAX_INTERACTIONS}) ---")
                            else:
                                print("--- [DRY RUN] Interaction skipped ---")
                                interaction_count += 1 
                        else:
                            print("--- [Safety] Skipping interaction (Randomized) ---")

                    # Always save to sheet
                    storage.save_interaction(post_data)
                    
                    # C. Close the Modal to return to the feed
                    browser.close_post_modal()
                    
                    # Global wait between posts
                    time.sleep(random.uniform(3.0, 6.0))

                except Exception as e:
                    if "Connection closed" in str(e) or "Target closed" in str(e):
                        print(f"  > [System] Connection lost: {e}")
                        browser.restart(config.INSTAGRAM_USERNAME, config.INSTAGRAM_PASSWORD)
                        continue # Skip to next post (or same one if re-fetched)
                    else:
                        print(f"  > [!] Error processing post {url}: {e}")

    except Exception as e:
        print(f"Fatal Error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        browser.stop()
        print("Done.")

if __name__ == "__main__":
    main()
