"""
Instagram Interaction Calibration Tool
=======================================
Run this once to record the exact positions of:
  1. Like button (heart icon)
  2. Comment input box (댓글 달기...)
  3. Post button (게시)

The script opens a post modal and walks you through clicking each element.
Positions are saved to calibration.json and reused for all future interactions.

Usage: python calibrate_like.py
"""
from browser import InstagramInteractionBrowser
import config
import time
import json

TARGETS = [
    {"key": "like", "label": "좋아요(Like) 하트 아이콘 ♡"},
    {"key": "comment_input", "label": "댓글 입력창 (댓글 달기...)"},
]

def wait_for_click(page, label):
    """Inject listener and wait for user's click."""
    page.evaluate("() => { window.__cal_click = null; }")
    page.evaluate("""
        () => {
            document.addEventListener('click', (e) => {
                window.__cal_click = {x: e.clientX, y: e.clientY};
            }, {capture: true, once: true});
        }
    """)
    print(f"\n>>> '{label}' 을(를) 클릭해주세요... <<<")
    
    for _ in range(120):  # 60 seconds timeout
        time.sleep(0.5)
        result = page.evaluate("() => window.__cal_click")
        if result:
            print(f"    ✓ 클릭 감지: ({result['x']:.0f}, {result['y']:.0f})")
            return result
    
    print(f"    ✗ 60초 안에 클릭이 감지되지 않았습니다.")
    return None

def calibrate():
    print("=" * 55)
    print("  Instagram Interaction Calibration Tool")
    print("=" * 55)
    print("모달이 열리면 아래 3가지를 순서대로 클릭해주세요:")
    for i, t in enumerate(TARGETS):
        print(f"  {i+1}. {t['label']}")
    print()
    
    browser = InstagramInteractionBrowser(headless=False)
    browser.start()
    
    if config.INSTAGRAM_USERNAME and config.INSTAGRAM_PASSWORD:
        browser.login(config.INSTAGRAM_USERNAME, config.INSTAGRAM_PASSWORD)
    
    browser.go_to_feed()
    time.sleep(2)
    
    url = browser.get_next_unprocessed_post_modal(set())
    if not url:
        print("[!] 게시물을 찾을 수 없습니다. 다시 시도해주세요.")
        browser.stop()
        return
    
    print(f"\n[OK] 모달 열림: {url}")
    
    # Get modal box
    modal_box = browser.page.evaluate("""
        () => {
            const modals = document.querySelectorAll("div[role='dialog']");
            for (const m of modals) {
                const r = m.getBoundingClientRect();
                if (r.width > 300 && r.height > 300) {
                    return {x: r.left, y: r.top, width: r.width, height: r.height};
                }
            }
            return null;
        }
    """)
    
    if not modal_box:
        print("[!] 모달 위치를 찾을 수 없습니다.")
        browser.stop()
        return
    
    print(f"모달: x={modal_box['x']:.0f}, y={modal_box['y']:.0f}, "
          f"w={modal_box['width']:.0f}, h={modal_box['height']:.0f}")
    
    calibration = {
        "modal_size": {"width": modal_box['width'], "height": modal_box['height']},
        "calibrated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    
    for target in TARGETS:
        click = wait_for_click(browser.page, target['label'])
        if not click:
            print(f"[!] '{target['label']}' 보정 실패. 중단합니다.")
            browser.stop()
            return
        
        rel_x = click['x'] - modal_box['x']
        rel_y = click['y'] - modal_box['y']
        
        calibration[target['key']] = {
            "absolute": {"x": click['x'], "y": click['y']},
            "relative": {"x": round(rel_x, 1), "y": round(rel_y, 1)},
            "percentage": {
                "x": round(rel_x / modal_box['width'], 4),
                "y": round(rel_y / modal_box['height'], 4)
            }
        }
        
        print(f"    → 모달 내 비율: ({rel_x / modal_box['width']:.1%}, {rel_y / modal_box['height']:.1%})")
        time.sleep(0.3)
    
    # Save
    cal_path = "calibration.json"
    with open(cal_path, 'w', encoding='utf-8') as f:
        json.dump(calibration, f, indent=2, ensure_ascii=False)
    
    print(f"\n{'=' * 55}")
    print(f"[SUCCESS] 보정 완료! → {cal_path}")
    print(f"{'=' * 55}")
    for t in TARGETS:
        pct = calibration[t['key']]['percentage']
        print(f"  {t['label']}: ({pct['x']:.1%}, {pct['y']:.1%})")
    print(f"\n이제 main.py를 실행하면 이 좌표를 자동으로 사용합니다.")
    
    browser.stop()

if __name__ == "__main__":
    calibrate()
