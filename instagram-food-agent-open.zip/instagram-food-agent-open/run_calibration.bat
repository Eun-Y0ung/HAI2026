@echo off
chcp 65001 >nul
title Instagram Bot - Calibration
echo ==========================================
echo   Click Position Calibration Tool
echo ==========================================
echo.
call C:\Users\USER\miniconda3\Scripts\activate.bat base
cd /d "c:\Users\USER\Desktop\antigravity\instagram-food-interaction-agent"
python calibrate_like.py
echo.
echo ==========================================
echo   Calibration complete. Press any key.
echo ==========================================
pause >nul
