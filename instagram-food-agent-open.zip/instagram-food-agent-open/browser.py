from playwright.sync_api import sync_playwright
import time
import random
import os
import base64

class InstagramInteractionBrowser:
    def __init__(self, headless=True):
        self.headless = headless
        self.browser = None
        self.context = None
        self.page = None
        self.playwright = None

    def start(self):
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(
            headless=self.headless,
            args=['--start-maximized']
        )
        
        state_path = "instagram_session.json"
        
        if os.path.exists(state_path):
            print(f"Loading session from {state_path}...")
        else:
            fallback_path = "../instagram-agent/instagram_session.json"
            if os.path.exists(fallback_path):
                print(f"Borrowing session from {fallback_path}...")
                state_path = fallback_path
            else:
                state_path = None

        if state_path:
            self.context = self.browser.new_context(
                no_viewport=True,
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                storage_state=state_path
            )
        else:
            self.context = self.browser.new_context(
                no_viewport=True,
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            )
            
        cursor_script = """
            document.addEventListener('DOMContentLoaded', () => {
                const cursor = document.createElement('div');
                cursor.style.width = '20px';
                cursor.style.height = '20px';
                cursor.style.borderRadius = '50%';
                cursor.style.backgroundColor = 'rgba(255, 0, 0, 0.5)';
                cursor.style.position = 'fixed';
                cursor.style.pointerEvents = 'none';
                cursor.style.zIndex = '9999999';
                cursor.style.transition = 'top 0.1s, left 0.1s';
                cursor.style.transform = 'translate(-50%, -50%)';
                document.body.appendChild(cursor);
                document.addEventListener('mousemove', e => {
                    cursor.style.left = e.clientX + 'px';
                    cursor.style.top = e.clientY + 'px';
                });
            });
        """
        self.context.add_init_script(cursor_script)
            
        self.page = self.context.new_page()

    def login(self, username, password):
        print(f"Logging in as {username}...")
        try:
            self.page.goto("https://www.instagram.com/accounts/login/")
            time.sleep(random.uniform(4.0, 7.0))

            if self.page.locator("article").count() > 0 or self.page.locator("svg[aria-label='Home']").count() > 0:
                print("Already logged in.")
                return

            self.page.wait_for_selector("input[name='username']", timeout=10000)
            self.page.type("input[name='username']", username, delay=random.randint(50, 150))
            self.page.type("input[name='password']", password, delay=random.randint(50, 150))
            self.page.click("button[type='submit']")
            time.sleep(random.uniform(6.0, 10.0))
            
            self.context.storage_state(path="instagram_session.json")
            print("Session saved.")
            self.handle_popups()
        except Exception as e:
            print(f"Login failed: {e}")

    def handle_popups(self):
        try:
            for label in ["나중에 하기", "Not Now"]:
                try:
                    btn = self.page.get_by_role("button", name=label).first
                    if btn.count() > 0 and btn.is_visible(timeout=1000):
                        print(f"  > [System] Dismissing '{label}' popup.")
                        btn.click()
                        time.sleep(1.0)
                except:
                    pass
        except Exception as e:
            pass

    def _js_get_coords(self, js_code):
        """Runs JS to get element center coordinates, bypassing Playwright's broken bounding_box."""
        try:
            return self.page.evaluate(js_code)
        except Exception as e:
            print(f"  > [JS] Coordinate extraction failed: {e}")
            return None

    def _human_click(self, x, y, label="target"):
        """Simulates human-like mouse movement to (x,y) and clicks."""
        print(f"  > [Virtual Human] Moving mouse to {label} at ({x:.1f}, {y:.1f})")
        self.page.mouse.move(x, y, steps=15)
        time.sleep(random.uniform(0.3, 0.8))
        self.page.mouse.click(x, y, delay=random.randint(50, 120))

    def _load_calibration(self):
        """Loads calibration.json (or legacy like_calibration.json)."""
        import json
        for name in ["calibration.json", "like_calibration.json"]:
            path = os.path.join(os.path.dirname(__file__) or '.', name)
            if os.path.exists(path):
                with open(path, 'r', encoding='utf-8') as f:
                    return json.load(f)
        return None

    def _get_modal_box(self):
        """Gets the current modal's bounding box via JS."""
        return self._js_get_coords("""
            () => {
                const modals = document.querySelectorAll("div[role='dialog']");
                for (const m of modals) {
                    const r = m.getBoundingClientRect();
                    if (r.width > 300 && r.height > 300) {
                        return {x: r.left, y: r.top, width: r.width, height: r.height};
                    }
                }
                return null;
            }
        """)

    def _calibrated_click(self, cal_key, label):
        """Clicks using calibrated coordinates for a given key (like, comment_input, post_button)."""
        cal = self._load_calibration()
        if not cal or cal_key not in cal:
            print(f"  > [!] '{cal_key}' 보정 데이터 없음. 'python calibrate_like.py' 실행 필요.")
            return False
        
        modal_box = self._get_modal_box()
        if not modal_box:
            print(f"  > [!] Modal not found.")
            return False
        
        pct = cal[cal_key].get('percentage', cal[cal_key].get('percentage_of_modal'))
        if not pct:
            print(f"  > [!] '{cal_key}' percentage data missing in calibration.")
            return False
        
        x = modal_box['x'] + (pct['x'] * modal_box['width']) + random.uniform(-4, 4)
        y = modal_box['y'] + (pct['y'] * modal_box['height']) + random.uniform(-4, 4)
        
        self._human_click(x, y, f"{label} (calibrated)")
        return True

    def like_post(self, target_hint=None, analyzer=None):
        """Likes the post by pinpointing the heart icon in the interaction bar."""
        print("  > [Interaction] Executing Like action...")
        try:
            # 1. Verification: Is it already liked?
            if self._verify_liked():
                print("  > already liked.")
                return True
            
            # 2. Pinpoint Discovery: Find the heart in the BOTTOM-RIGHT interaction area
            coords = self._js_get_coords("""
                () => {
                    const dialogs = Array.from(document.querySelectorAll("div[role='dialog']")).filter(d => d.getBoundingClientRect().width > 300);
                    const dialog = dialogs[0] || document.querySelector("article");
                    if (!dialog) return null;
                    
                    const modalRect = dialog.getBoundingClientRect();
                    const svgs = dialog.querySelectorAll("svg");
                    
                    for (const svg of svgs) {
                        const label = svg.getAttribute("aria-label") || "";
                        const r = svg.getBoundingClientRect();
                        
                        if ((label.includes("Like") || label.includes("좋아요")) && !label.includes("취소") && !label.includes("Unlike")) {
                            // Check for main interaction heart: Bottom-Right of the modal
                            if (r.width > 20 && r.left > modalRect.left + modalRect.width * 0.4 && r.top > modalRect.top + modalRect.height * 0.3) {
                                const btn = svg.closest("div[role='button'], button");
                                const target = btn ? btn.getBoundingClientRect() : r;
                                return {x: target.left + target.width / 2, y: target.top + target.height / 2};
                            }
                        }
                    }
                    return null;
                }
            """)
            
            if coords:
                jx = coords['x'] + random.uniform(-4, 4)
                jy = coords['y'] + random.uniform(-4, 4)
                self._human_click(jx, jy, "Like ♡ (pinpoint)")
                time.sleep(2.5) # Give IG a bit more time to trigger UI change
                
                if self._verify_liked():
                    print("  > [Interaction] Verified: Like registered successfully (Pinpoint).")
                    return True
                else:
                    print("  > [!] Pinpoint click did not change UI state. Trying fallback...")
            
            # 3. Fallback: Calibration + Verification
            if self._calibrated_click("like", "Like ♡"):
                time.sleep(2.5)
                if self._verify_liked():
                    print("  > [Interaction] Verified: Like registered (Calibrated).")
                    return True

            # 4. Final Fallback: Double-click
            img_coords = self._js_get_coords("""
                () => {
                    const dialog = document.querySelector("div[role='dialog']");
                    if (!dialog) return null;
                    const media = Array.from(dialog.querySelectorAll("img, video")).sort((a, b) => (b.offsetWidth * b.offsetHeight) - (a.offsetWidth * a.offsetHeight))[0];
                    if (media) { const r = media.getBoundingClientRect(); return {x: r.left + r.width/2, y: r.top + r.height/2}; }
                    return null;
                }
            """)
            if img_coords:
                self.page.mouse.move(img_coords['x'], img_coords['y'])
                time.sleep(0.5)
                self.page.mouse.dblclick(img_coords['x'], img_coords['y'])
                time.sleep(3.5)
                if self._verify_liked():
                    print("  > [Interaction] Verified: Like registered (Double-click).")
                    return True
            
            print("  > [!] All Like methods failed. UI state remained 'Unliked'.")
            return False
        except Exception as e:
            print(f"  > [!] Fatal Error during Like: {e}")
            return False

    def _verify_liked(self):
        """Strictly verifies if the ACTIVE post is liked, ignoring background elements."""
        return self.page.evaluate("""
            () => {
                // 1. Prioritize 'dialog' role, then fallback to visible 'article'
                const containers = Array.from(document.querySelectorAll("div[role='dialog'], article"))
                    .filter(c => {
                        const r = c.getBoundingClientRect();
                        return r.width > 300 && r.height > 300 && window.getComputedStyle(c).display !== 'none';
                    });
                
                // Sort to get the most specific container (dialog usually comes after articles in DOM)
                const dialogs = containers.filter(c => c.getAttribute('role') === 'dialog');
                const active = dialogs.length > 0 ? dialogs[0] : containers[0];
                
                if (!active) return false;
                
                // 2. Look for any sign of "Liked" state
                // Includes common Korean and English labels for success
                const signs = active.querySelectorAll("[aria-label*='Unlike'], [aria-label*='취소'], [aria-label*='unlike'], [aria-label='Liked']");
                for (const sign of signs) {
                    const r = sign.getBoundingClientRect();
                    // Must be a main heart (>20px)
                    if (r.width > 20) return true;
                }
                return false;
            }
        """)

    def _is_comment_field_empty(self):
        """Checks if the comment input field is empty via JS."""
        return self.page.evaluate("""
            () => {
                const input = document.querySelector("textarea, div[contenteditable='true']");
                if (!input) return true; 
                const text = input.tagName === 'TEXTAREA' ? input.value : input.innerText;
                // IGNORE everything if it's just whitespace or line breaks
                const cleaned = text.replace(/\\n/g, '').replace(/\\s/g, '').trim();
                if (cleaned.length === 0) return true;
                
                // Fallback: Check if the 'Post' button is disabled/gone
                const postBtn = Array.from(document.querySelectorAll("div[role='button'], button"))
                    .find(b => b.innerText.includes('게시') || b.innerText.includes('Post'));
                if (!postBtn || postBtn.getAttribute('disabled') !== null) return true;

                return false;
            }
        """)

    def restart(self, username, password):
        print("  > [System] Restarting browser due to connection error...")
        try:
            self.stop()
            time.sleep(2)
            self.start()
            self.login(username, password)
            return True
        except Exception as e:
            print(f"  > [!] Failed to restart browser: {e}")
            return False

    def post_comment(self, comment_text, analyzer=None):
        """Posts a comment using Enter key by default for maximum reliability."""
        print(f"  > [Interaction] Attempting to post comment: {comment_text[:30]}...")
        try:
            # Step 1: Click and Focus (calibrated input box)
            clicked = self._calibrated_click("comment_input", "Comment input")
            if not clicked:
                try:
                    self.page.click("textarea, div[contenteditable='true']", timeout=3000)
                except: pass
            
            time.sleep(0.8)
            
            # Step 2: Type comment
            print(f"  > [Human Behavior] Typing comment...")
            for char in comment_text:
                self.page.keyboard.type(char, delay=0)
                time.sleep(random.uniform(0.05, 0.35))
            time.sleep(1.0)
            
            # Step 3: Submit via ENTER (Primary method)
            print("  > [Interaction] Submitting via 'Enter' key...")
            self.page.keyboard.press("Enter")
            time.sleep(4.0)
            
            # Step 4: Verification & JS Fallback
            if self._is_comment_field_empty():
                print("  > [Interaction] Verified: Comment published successfully (Enter).")
                return True
            
            # Final Fallback: JS click on Post button
            print("  > [!] Enter failed. Trying final JS-based Post button click...")
            self.page.evaluate("""
                () => {
                    const btns = Array.from(document.querySelectorAll("div[role='button'], button"));
                    const postBtn = btns.find(b => {
                        const t = b.innerText;
                        return (t.includes('게시') || t.includes('Post')) && b.getBoundingClientRect().width > 0;
                    });
                    if (postBtn) postBtn.click();
                }
            """)
            time.sleep(4.0)
            
            if self._is_comment_field_empty():
                print("  > [Interaction] Verified: Comment published successfully (JS click).")
                return True
            
            print("  > [!] All comment submission methods failed.")
            return False
                
        except Exception as e:
            print(f"  > [!] Fatal Error during Commenting: {e}")
            return False

    def go_to_feed(self):
        print("  > [Navigation] Returning to feed...")
        try:
            self.page.goto("https://www.instagram.com/")
            time.sleep(random.uniform(2.0, 3.0))
            self.handle_popups()
        except Exception as e:
            print(f"  > [!] Error returning to feed: {e}")

    def get_next_unprocessed_post_modal(self, processed_urls):
        print("  > [System] Looking for a new post on the feed...")
        for _ in range(5):
            self.page.wait_for_selector("article", timeout=5000)
            articles = self.page.locator("article").all()
            
            for article in articles:
                if not article.is_visible(): continue
                try:
                    url_elem = article.locator("a[href^='/p/'], a[href^='/reel/']").first
                    if url_elem.count() == 0: continue
                    href = url_elem.get_attribute("href").split('?')[0]
                    if not href.endswith('/'): href += '/'
                    url = "https://www.instagram.com" + href
                except: continue
                    
                if url in processed_urls: continue
                    
                print(f"  > [System] Found new post: {url}")
                
                try:
                    article.scroll_into_view_if_needed()
                    time.sleep(1.0)
                    
                    comment_btn = article.locator("svg[aria-label='Comment'], svg[aria-label='댓글 달기'], svg[aria-label='댓글']").locator("xpath=./ancestor::button|./ancestor::a|./..").first
                    if comment_btn.count() > 0:
                        comment_btn.click(force=True)
                        time.sleep(2.0)
                        
                        modal = None
                        for m_dialog in self.page.locator("div[role='dialog']").all():
                            if m_dialog.is_visible():
                                modal = m_dialog
                                break
                                
                        if modal:
                            print("  > [System] Post Modal opened successfully.")
                            return url
                except Exception as e:
                    print(f"  > [!] Error accessing post element: {e}")
                    continue
            
            print("  > [System] Scrolling down for more posts...")
            self.page.mouse.wheel(0, 800)
            time.sleep(2.0)
            
        return None

    def close_post_modal(self):
        try:
            print("  > [System] Closing post modal...")
            self.page.keyboard.press("Escape")
            time.sleep(1.5)
            for modal in self.page.locator("div[role='dialog']").all():
                if modal.is_visible():
                    self.page.keyboard.press("Escape")
                    break
        except: pass

    def parse_post_details_from_modal(self, url):
        print(f"Parsing post from modal: {url}")
        data = {
            "url": url, 
            "caption": "", 
            "hashtags": [], 
            "thumbnail_url": "",
            "existing_comments": [],
            "ui_snapshot": None
        }
        try:
            modal = None
            for m_dialog in self.page.locator("div[role='dialog']").all():
                if m_dialog.is_visible():
                    modal = m_dialog
                    break
                    
            if not modal: return data

            try:
                video_elem = modal.locator("video").first
                if video_elem.count() > 0:
                    self.page.evaluate("(vid) => { vid.pause(); }", video_elem)
                    print("  > [System] Paused video inside modal.")
            except: pass
            
            try: 
                caption_elem = modal.locator("h1").first
                data["caption"] = caption_elem.inner_text()
            except: pass
            
            try:
                screenshot_bytes = modal.screenshot(type="jpeg", quality=60)
                data["screenshot_base64"] = base64.b64encode(screenshot_bytes).decode('utf-8')
            except Exception as e:
                print(f"  > [!] Modal screenshot error: {e}")

            try:
                container = modal if modal else self.page
                comment_blocks = container.locator("ul li, div._a9z6 li").all()
                comments_found = []
                for block in comment_blocks:
                    text = block.inner_text().strip()
                    if text and ("답글 달기" in text or "Reply" in text):
                        cleaned_text = text.split('\n답글 달기')[0].split('\nReply')[0].replace('\n', ' : ')
                        comments_found.append(cleaned_text)
                        if len(comments_found) >= 20: break
                
                data["existing_comments"] = comments_found
            except: pass
            
            try:
                if hasattr(self.page, "accessibility"):
                    data["ui_snapshot"] = self.page.accessibility.snapshot()
                else:
                    data["ui_snapshot"] = {"error": "Accessibility API not available on this Page object"}
            except Exception as acc_e:
                data["ui_snapshot"] = {"error": str(acc_e)}
            
        except Exception as e:
            print(f"  > [!] Error parsing post details: {e}")
        return data

    def stop(self):
        if self.context: self.context.close()
        if self.browser: self.browser.close()
        if self.playwright: self.playwright.stop()
