# 🔍 코드 레퍼런스 (Code Reference)

---

## 📋 목차

1. [main.py — 메인 실행 루프](#1-mainpy)
2. [browser.py — 브라우저 제어](#2-browserpy)
3. [analyzer.py — AI 분석 엔진](#3-analyzerpy)
4. [storage.py — 구글 시트 기록](#4-storagepy)
5. [media_processor.py — 이미지 처리](#5-media_processorpy)
6. [calibrate_like.py — 클릭 위치 보정](#6-calibrate_likepy)
7. [config.py — 환경 설정 로딩](#7-configpy)

---

## 1. `main.py`

### 역할
프로그램의 **시작점(진입점)**입니다. 모든 모듈을 조립하고, "피드 탐색 → 분석 → 인터랙션 → 기록" 루프를 실행합니다.

### 상단 안전 설정
```python
DRY_RUN = False          # True면 분석만 하고 실제 클릭/댓글 안 함
MAX_INTERACTIONS = 3     # 한 번 실행에 최대 몇 개 게시물에 반응할지
INTERACTION_PROBABILITY = 1.0  # 반응 확률 (1.0 = 100%)
```

### `main()` 함수 흐름

| 단계 | 코드 위치 | 설명 |
|:---:|---|---|
| ① | `browser.start()` / `browser.login()` | 브라우저를 열고 인스타그램에 로그인 |
| ② | `browser.go_to_feed()` | 인스타그램 홈 피드로 이동 |
| ③ | `browser.get_next_unprocessed_post_modal()` | 피드에서 아직 처리하지 않은 게시물을 찾아 모달(팝업) 열기 |
| ④ | `browser.parse_post_details_from_modal()` | 모달에서 캡션, 댓글, 스크린샷 등 데이터 수집 |
| ⑤ | `analyzer.analyze_and_suggest()` | GPT-4o가 게시물을 분석하여 레벨/점수/추천댓글 생성 |
| ⑥ | `save_debug_report()` | **(신규)** 분석에 사용된 스크린샷과 수집된 텍스트를 `debug_data` 폴더에 기록 |
| ⑦ | `browser.like_post()` | 핀포인트(자동) 또는 보정 좌표로 좋아요 클릭 |
| ⑧ | `browser.post_comment()` | 보정 좌표로 댓글 입력 → 타이핑 → 게시 |
| ⑨ | `storage.save_interaction()` | 결과를 구글 스프레드시트에 기록 |
| ⑩ | `browser.close_post_modal()` | 모달 닫고 다음 게시물로 이동 |

### `save_debug_report(url, post_data)` — 데이터 검증 기록
- **역할**: AI가 무엇을 보고 판단했는지 사용자가 직접 확인할 수 있도록 로그를 남깁니다.
- **저장소**: `debug_data/` 폴더
- **파일**: 
  - `.jpg`: AI가 분석한 실제 화면 캡처
  - `.json`: 수집된 본문, 댓글 목록, AI의 분석 결과 전문

### 안전 장치
- **댓글 수 체크**: 기존 댓글이 5개 미만인 게시물에는 댓글을 달지 않음 (초기 게시물에 봇이 댓글 다는 것 방지)
- **모달 존재 여부 체크**: 인터랙션 전에 모달이 아직 열려있는지 확인
- **Connection Error 처리**: 연결이 끊기면 브라우저를 자동 재시작

---

## 2. `browser.py`

### 역할
**Playwright** 라이브러리를 사용해 실제 브라우저(Chromium)를 제어합니다. 인스타그램의 모든 UI 조작(클릭, 타이핑, 스크롤 등)을 담당합니다.

### 클래스: `InstagramInteractionBrowser`

---

#### `start()` — 브라우저 시작
```
세션 파일 존재? → 쿠키 자동 로딩 (재로그인 불필요)
                → User-Agent를 실제 Chrome처럼 설정
                → 빨간 커서 시각화 스크립트 주입 (마우스 위치 확인용)
```
- `instagram_session.json`: 로그인 상태(쿠키)가 저장된 파일
- `cursor_script`: 마우스가 어디를 가리키는지 빨간 원으로 보여주는 시각적 디버깅 도구

---

#### `_js_get_coords(js_code)` — JavaScript 좌표 추출기
```python
self.page.evaluate(js_code)  # 브라우저 내부에서 JS 코드 직접 실행
```
- Playwright의 `bounding_box()` 대신 브라우저 네이티브 `getBoundingClientRect()`를 사용
- **왜?** Playwright는 인스타그램의 CSS 투명 오버레이 때문에 일부 요소(특히 SVG 하트)의 좌표를 `None`으로 반환하지만, JS의 `getBoundingClientRect()`는 항상 정확한 좌표를 반환합니다.

---

#### `_human_click(x, y, label)` — 사람처럼 마우스 이동 + 클릭
```python
self.page.mouse.move(x, y, steps=15)   # 15단계에 걸쳐 부드럽게 이동
self.page.mouse.click(x, y, delay=...)  # 50~120ms 딜레이로 자연스럽게 클릭
```
- `steps=15`: 순간이동이 아닌, 현재 위치에서 목표까지 15개 중간 지점을 거쳐 부드럽게 이동
- `delay`: 마우스 버튼을 누르고 떼는 사이에 랜덤 지연 시간 적용

---

#### `_load_calibration()` — 보정 데이터 로딩
```python
# 우선순위: calibration.json > like_calibration.json (레거시)
```
- `calibrate_like.py`로 생성된 JSON 파일을 읽어옵니다.

---

#### `_get_modal_box()` — 현재 모달 위치 파악
```python
# JavaScript로 div[role='dialog']의 위치와 크기를 가져옴
```
- 모달의 x, y, width, height를 반환
- 보정 좌표를 실제 화면 좌표로 변환할 때 기준점으로 사용

---

#### `like_post()` — 좋아요 누르기 (3단계 전략)
단순한 클릭이 아니라, 성공률을 극대화하기 위해 3단계로 작동합니다.

1. **1단계: 핀포인트 인식 (Pinpoint Discovery)**
   - JS를 사용해 모달창의 **우측 하단 인터랙션 영역**에 있는 하트 SVG를 자동으로 찾아냅니다. 
   - 배경의 다른 하트나 영상 위 오버레이 하트와 헷갈리지 않도록 위치 필터링을 거칩니다.
2. **2단계: 보정 좌표 클릭 (Calibration Fallback)**
   - 자동 인식이 실패할 경우, 사용자가 `calibrate_like.py`로 설정한 좌표를 사용합니다.
3. **3단계: 미디어 더블 클릭 (Double Click Fallback)**
   - 위 방법이 모두 실패하면 게시물 이미지/영상을 더블 클릭하여 좋아요를 시도합니다.

---

#### `_verify_liked()` — 좋아요 상태 검증 (시야 교정)
- **역할**: 실제로 좋아요가 성공했는지 UI 상태를 확인합니다.
- **핵심 로직**:
  - `role="dialog"`(팝업창)가 있으면 배경 피드를 무시하고 **오직 팝업창 내의 상태**만 확인합니다.
  - 하트의 라벨이 "좋아요 취소", "Unlike", "취소", "Liked" 등으로 변했는지 체크합니다.
  - 이를 통해 "실제로 성공했는데 로그에는 실패로 뜨는 현상"을 완벽하게 방지합니다.

---

#### `post_comment(comment_text)` — 댓글 달기
```
① _calibrated_click("comment_input") → 댓글 입력창 클릭
② keyboard.type(comment_text, delay=...) → 사람 속도로 한 글자씩 타이핑
③ _calibrated_click("post_button") → 게시 버튼 클릭
④ textarea가 비었는지 JS로 검증 (실제로 게시됐는지 확인)
⑤ 여전히 텍스트가 남아있으면 Enter 키를 한 번 더 누르고 재검증
```
- **거짓 성공 방지**: textarea에 아직 내가 쓴 글이 남아있으면 `return False` (시트에 실패로 기록됨)

---

#### `get_next_unprocessed_post_modal(processed_urls)` — 새 게시물 탐색
```
피드의 article 태그들을 순회 → URL 추출 → 이미 처리한 URL이면 건너뛰기
→ 댓글 아이콘 클릭하여 모달 열기 → 최대 5번 스크롤
```

---

#### `parse_post_details_from_modal(url)` — 모달에서 데이터 수집
수집하는 항목:
- `caption`: 게시물 본문 (h1 태그)
- `screenshot_base64`: 모달 화면 캡처 (GPT-4o에 전달용)
- `existing_comments`: 기존 댓글 목록 (최대 20개)
- `ui_snapshot`: 접근성 트리 (UI 구조 정보)

---

## 3. `analyzer.py`

### 역할
**GPT-4o Vision** API를 호출하여 게시물을 분석하고, 인터랙션 여부와 추천 댓글을 생성합니다.

### 클래스: `InteractionAnalyzer`

---

#### `__init__()` — 초기화
```python
self.hotplace_keywords = ["웨이팅", "오픈런", "핫플", ...]  # 핫플 키워드
self.food_keywords = ["존맛", "JMT", "미친맛", ...]        # 음식 키워드
self.reaction_keywords = ["어디예요", "저장", "가고싶다", ...] # 반응 키워드
```
- LLM이 실패했을 때를 대비한 **규칙 기반 예비 분석기** 역할

---

#### `analyze_and_suggest()` — 메인 분석 함수
```
① GPT-4o Vision 호출 (_analyze_with_llm)
  → 성공: LLM이 판단한 레벨, 점수, 추천 댓글 반환
  → 실패: 규칙 기반 분석(_calculate_rule_score)으로 대체
```

**반환하는 데이터:**
| 필드 | 의미 |
|---|---|
| `final_level` | 0=무시, 1=관심, 2=적극 반응 |
| `score` | 0.0~1.0 점수 |
| `interact_like` | 좋아요 할지 여부 (True/False) |
| `interact_comment` | 댓글 달지 여부 (True/False) |
| `suggested_reply` | AI가 생성한 추천 댓글 (한국어) |
| `rationale` | 판단 근거 설명 |

---

#### `_analyze_with_llm()` — GPT-4o Vision 호출
**프롬프트 핵심 지시사항:**
- 카페/식당/음식 브랜드 추천 게시물인지 확인
- 집밥/레시피/일상 공유는 Level 0으로 제외
- 릴스(영상) 썸네일에 사람 얼굴만 보여도, 캡션이 맛집 리뷰면 Level 1/2로 판정
- 기존 댓글의 분위기를 흉내 낸 자연스러운 한국어 댓글 생성

```python
response_format={"type": "json_object"}  # JSON 형식으로 강제 출력
max_tokens=800                           # 응답 길이 제한
```

---

#### `_calculate_rule_score()` — 규칙 기반 점수 계산 (백업)
```
핫플 키워드 발견 → +0.2점
음식 키워드 발견 → +0.3점
반응 키워드 발견 → +0.4점
→ 총점 0.3 미만 = Level 0, 0.3~0.7 = Level 1, 0.7+ = Level 2
```

---

## 4. `storage.py`

### 역할
구글 스프레드시트에 분석/인터랙션 결과를 기록합니다.

### 클래스: `InteractionStorageManager`

---

#### `_setup()` — 초기 연결
```python
scope = ["spreadsheets", "drive"]    # Google Sheets + Drive API 권한
client.open_by_key(self.sheet_id)    # 시트 ID로 스프레드시트 열기
```
- 시트의 1행에 헤더가 없으면 자동으로 헤더를 삽입합니다.

**시트 컬럼 구조:**
| Time | URL | Content Preview | Analysis Level | Score | Rationale | Suggested Reply | Interacted (Like) | Interacted (Comment) |

---

#### `save_interaction(data)` — 한 행 기록
```python
self.sheet.append_row(row)  # 시트 맨 아래에 새 행 추가
```

---

#### `get_processed_urls()` — 처리 완료 URL 가져오기
```python
urls = self.sheet.col_values(2)  # B열(URL 컬럼) 전체를 읽어옴
return set(urls)                 # 중복 체크용 Set으로 반환
```
- 이미 처리한 게시물에 다시 반응하지 않도록 하는 핵심 안전장치

---

## 5. `media_processor.py`

### 역할
이미지 URL을 다운로드하여 **base64 문자열**로 변환합니다.

### `encode_image_from_url(image_url)`
```python
response = requests.get(image_url, timeout=10)   # 이미지 다운로드
encoded = base64.b64encode(response.content)      # base64로 변환
```
- 변환된 문자열은 GPT-4o Vision API에 전달할 때 `data:image/jpeg;base64,...` 형태로 사용됩니다.
- 모달 스크린샷이 없을 때 썸네일 URL로 대체하는 백업 수단

---

## 6. `calibrate_like.py`

### 역할
사용자가 직접 클릭하여 **좋아요/댓글/게시 버튼의 위치를 기록**하는 보정 도구입니다.

### 동작 방식
```
① 인스타그램 로그인 → 피드 이동 → 첫 번째 게시물 모달 열기
② 모달의 위치(x, y, width, height) 측정
③ JavaScript 클릭 이벤트 리스너 주입 → 사용자의 클릭 대기 (×3번)
④ 각 클릭 좌표를 모달 대비 비율(%)로 변환
⑤ calibration.json에 저장
```

### 저장되는 데이터 구조
```json
{
  "like": {
    "percentage": {"x": 0.48, "y": 0.804}    // 모달의 48%, 80.4% 지점
  },
  "comment_input": {
    "percentage": {"x": 0.534, "y": 0.955}
  },
  "post_button": {
    "percentage": {"x": 0.773, "y": 0.962}
  }
}
```

### 왜 비율(%)로 저장하나?
모달의 크기는 창 크기에 따라 달라질 수 있지만, 하트·댓글·게시 버튼의 **모달 내 상대적 위치 비율**은 항상 동일합니다. 따라서 비율로 저장하면 어떤 해상도에서든 정확한 위치를 계산할 수 있습니다.

---

## 7. `config.py`

### 역할
`.env` 파일에서 환경 변수를 읽어 파이썬 변수로 제공합니다.

```python
load_dotenv(override=True)  # .env 파일 로딩

INSTAGRAM_USERNAME = os.getenv("INSTAGRAM_USERNAME")
INSTAGRAM_PASSWORD = os.getenv("INSTAGRAM_PASSWORD")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GOOGLE_SHEET_ID = os.getenv("GOOGLE_SHEET_ID")
GOOGLE_SHEETS_CREDENTIALS_FILE = "credentials.json"  # 기본값
```

- `override=True`: 시스템 환경변수보다 `.env` 파일의 값을 우선 적용
- API 키 로딩 시 앞 8자 + 뒤 4자만 보여주고 중간은 `...`으로 마스킹하여 보안 유지

---

## 🔄 전체 실행 흐름 요약

```
[사용자] python calibrate_like.py     ← 최초 1회: 클릭 위치 보정
         ↓
[사용자] python main.py               ← 봇 시작
         ↓
    ┌─────────────────────────────┐
    │  config.py → .env 변수 로딩  │
    │  storage.py → 시트 연결      │
    │  browser.py → 브라우저 실행   │
    └─────────────────────────────┘
         ↓
    ┌──── 루프 시작 ─────────────────────────────────────────┐
    │  browser → 피드에서 새 게시물 모달 열기                  │
    │  browser → 캡션, 댓글, 스크린샷 수집                    │
    │    └ (스크린샷 실패 시) media_processor → 썸네일 다운로드 │
    │  analyzer → GPT-4o로 분석 (레벨/점수/추천댓글)          │
    │  browser → calibration.json 기반 좋아요 클릭            │
    │  browser → calibration.json 기반 댓글 입력+게시         │
    │  storage → 구글 시트에 결과 기록                        │
    │  browser → 모달 닫기 → 다음 게시물                      │
    └──── MAX_INTERACTIONS에 도달하면 종료 ───────────────────┘
```
