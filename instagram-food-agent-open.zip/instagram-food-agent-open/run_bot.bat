@echo off
chcp 65001 >nul
title Instagram Interaction Bot
echo ==========================================
echo   Instagram Interaction Bot - Starting...
echo ==========================================
echo.
call C:\Users\USER\miniconda3\Scripts\activate.bat base
cd /d "c:\Users\USER\Desktop\antigravity\instagram-food-interaction-agent"
python main.py
echo.
echo ==========================================
echo   Bot finished. Press any key to close.
echo ==========================================
pause >nul
